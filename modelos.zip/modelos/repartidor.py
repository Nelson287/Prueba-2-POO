from datetime import datetime 

class Repartidor:
    def __init__(self, id=None, nombre ="", telefono = "", estado = "", fecha_ingreso = ""):
        self.id = id
        self.nombre = nombre
        self.telefono = telefono
        self.estado = estado
        self.fecha_ingreso = fecha_ingreso if fecha_ingreso else datetime.now()
    def __str__(self):
        return f"repartidor(id={self.id}, nombre = '{self.nombre}', telefono = '{self.telefono}', estado = '{self.estado}', fecha_ingreso = '{self.fecha_ingreso}')"