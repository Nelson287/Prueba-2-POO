from mysql.connector import Error
from modelos import repartidor
from db_conexion import DatabaseConnection

class RepartidorOperaciones:
    def __init__(self):
        self.db_conexion = DatabaseConnection()


#Funcion para agregar productos
    def agregar(self, repartidor) :
        conexion = self.db_conexion.get_connection()
        try:
            cursor = conexion.cursor()
            query = ("insert into repartidor (nombre, telefono, estado) values (%s, %s, %s)")
            valores = (repartidor.nombre, repartidor.telefono, repartidor.estado)
            cursor.execute(query, valores)
            conexion.commit()
            repartidor.id = cursor.lastrowid
            print("Repartidor ingresado correctamente")
            return repartidor
        
        except Error as e:
            print(f"Error al agregar repartidor: {e}")
        
        finally:
            cursor.close()

#Funcion para listar/obtener datos
    def listar(self): 
        conexion = self.db_conexion.get_connection()
        try:
            cursor = conexion.cursor()
            query = "select * from Repartidor"
            cursor.execute(query)
            resultados = cursor.fetchall()
            return [repartidor(**resultado) for resultado in resultados]
        
        except Error as e:
            print(f"Error al listar repartidores: ")
        
        finally: 
            if cursor:
                cursor.close()
