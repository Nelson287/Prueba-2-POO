from mysql.connector import Error 
from modelos import producto
from db_conexion import DataBaseConnection

class ProductoOperaciones :
    def __init__(self):
        self.db_conexion = DataBaseConnection()

#Funcion para agregar productos
    def agregar(self, producto) :
        conexion = self.db_conexion.get_connection()
        try:
            cursor = conexion.cursor()
            query = ("insert into producto (nombre, descripcion, precio, tipo_producto, fecha_ingreso) values(%s, %s, %s, %s, %s)")
            valores = (producto.nombre, producto.descripcion, producto.precio, producto.tipo_producto, producto.fecha_ingreso)
            cursor.execute(query, valores)
            conexion.commit()
            producto.id = cursor.lastrowid
            print("Producto ingresado correctamente")
            return producto
        
        except Error as e:
            print(f"Error al agregar producto: {e}")
        
        finally:
            cursor.close()

#Funcion para listar/obtener datos
    def listar(self): 
        conexion = self.db_conexion.get_connection()
        try:
            cursor = conexion.cursor()
            query = "select * from producto"
            cursor.execute(query)
            resultados = cursor.fetchall()
            return [producto(**resultado) for resultado in resultados]
        except Error as e:
            print(f"Error al listar Producto: ")
        
        finally: 
            if cursor:
                cursor.close()
